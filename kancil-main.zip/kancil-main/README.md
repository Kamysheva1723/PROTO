# Kancil

Kancil is a simple web app that shows how LlamaIndex can be used.